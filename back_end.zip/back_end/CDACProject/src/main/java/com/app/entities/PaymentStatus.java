package com.app.entities;

public enum PaymentStatus {
 UNPAID, PAID;
}
