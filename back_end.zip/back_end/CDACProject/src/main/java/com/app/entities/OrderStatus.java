package com.app.entities;

public enum OrderStatus {
		INCART, INPROCESS, DELIVERED;

}
