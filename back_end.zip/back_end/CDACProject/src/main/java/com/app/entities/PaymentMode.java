package com.app.entities;

public enum PaymentMode {
	CASH_ON_DELIVERY, CARD, NEFT; 

}
