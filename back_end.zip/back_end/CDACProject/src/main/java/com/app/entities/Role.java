package com.app.entities;

public enum Role {
	ROLE_ADMIN, ROLE_DISTRIBUTOR, ROLE_CUSTOMER, ROLE_DELIVERYPERSON;

}
